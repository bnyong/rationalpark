// TOP Right -개강일정안내...슬라이드UP 함수
function slideupTop(){

	$(".top_right ul").stop(true,true).animate({"margin-top":"-=20px"},1000,function(){ 		
		$(".top_right ul li:first-child").appendTo(".top_right ul"); 	
		$(this).css({"margin-top":"0"}); 
	});

}


// Review-수강후기 ...슬라이드UP 함수
function slideupBottom(){

	$(".slide").stop(true,true).animate({"margin-top":"-=150px"},1000,function(){ 		
		$(".slide li:first-child").appendTo(".slide"); 	
		$(this).css({"margin-top":"0"}); 
	});

}


$(document).ready(function(){
	
	setInterval(slideupTop,5000);  //함수 자동화
	setInterval(slideupBottom,5000);  //함수 자동화


	//TOP Mobile Menu.............................

	/*--->>>메뉴버튼(햄버거메뉴)*/
	$(".gnb_list").css({"left":"-60%"});  /*처음위치*/

	
	/*메뉴버튼*/
	$(".gnb_btn").click(function(){  
		$(".gnb_list").stop(true,true).animate({"left":0});
		$(".back").stop(true,true).fadeIn(); //메뉴 뒤 검정배경 등장
	});


	/*닫기버튼*/	
	$(".gnb .close").click(function(){  
		$(".gnb_list").stop(true,true).animate({"left":"-60%"});
		$(".back").stop(true,true).fadeOut(); //메뉴 뒤 검정배경 사라짐
	});




	//Footer-TOP버튼 클릭하면 맨 위로....................

	$(".footMenu ul li:last-child").click(function(){
		$("body,html").animate({scrollTop:"0"},700);
		return false;
	});


	//빠른상담신청하기..................................

	/*--->>>빠른상담 폼 올리고 내려가기*/

	$(".quick_btn").click(function(){
		$(".onform").stop(true,true).animate({bottom:"0px"},500);
		return false;
	});

	$(".quickForm>span").click(function(){
		$(".onform").stop(true,true).animate({bottom:"-350px"},500);
	});


	/*--->>>체크박스 이미지 바꾸기*/

	chk=true;

	$(".check").click(function(){
		
		if(chk){
			$(this).html("<i class='material-icons checkoff'>check</i>").hide().fadeIn();
			chk=false;
		}else{
			$(this).html("<i class='material-icons checkoff'>check_box_outline_blank</i>").hide().fadeIn();
			chk=true;
		}

	});


	/*--->>>입력폼에 커서 클릭시 가로선 나오기*/

	$("#name,#hp").focus(function(){
		$(this).css({"border-bottom":"2px solid #139aba","outline":"none","transition":"all 0.4s"});
	});

	$("#name,#hp").blur(function(){
		$(this).css({"border-bottom":"none","transition":"all 0.4s"});
	});


	//QuickMenu(close/open)...........................

	bb=true;
	$(".quick_toggle").click(function(){
		
		$(this).toggleClass("quick_close");

		if(bb){
			$(".quick_icon .icon5").stop(true,true).animate({"bottom":"50px"},500,"easeOutBack");
			$(".quick_icon .icon4").stop(true,true).animate({"bottom":"100px"},500,"easeOutBack");
			$(".quick_icon .icon3").stop(true,true).animate({"bottom":"150px"},500,"easeOutBack");
			$(".quick_icon .icon2").stop(true,true).animate({"bottom":"200px"},500,"easeOutBack");
			$(".quick_icon .icon1").stop(true,true).animate({"bottom":"250px"},500,"easeOutBack");
			bb=false;

		}else{
			$(".quick_icon li").stop(true,true).animate({"bottom":"0px"},200);
			bb=true;
		}

	});


	//SUB-교육과정...................................................

	$(".list_no>li").click(function(){
		$(".list_no>li").not(this).find("ul").stop(true,true).slideUp(200);
		$(this).find("ul").stop(true,true).slideToggle(200);
	});


	//SUB-국비교육...................................................

	$(".panel>li:not(:first)").hide();
	//첫번째를 제외한 나머지 내용 숨기기

	$(".tab>li").click(function(){
		$(".tab>li").removeClass("selected");//기존선택된 selected 클래스삭제
		$(this).addClass("selected");//새로 선택된 selected 클래스 생성
		$(".panel>li").hide();//기존의 보여진 내용 숨기기
		$($(this).find(">a").attr("href")).show();//새로 선택된 내용 href 연결된내용 보여주기
	});


	//SUB-포트폴리오...................................................

	$(".po_list .btn1").click(function(){
		$(this).hide();		
		$(".po_list>ul>li:nth-child(n+7):nth-child(-n+12)").fadeIn();
	});

	$(".po_list .btn2").click(function(){
		$(this).hide();		
		$(".po_list>ul>li:nth-child(n+13):nth-child(-n+18)").fadeIn();
	});

	$(".po_list .btn3").click(function(){
		$(this).hide();		
		$(".po_list>ul>li:nth-child(n+19):nth-child(-n+23)").fadeIn();
	});


});